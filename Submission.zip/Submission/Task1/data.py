import yfinance as yf
import sqlite3
import pandas as pd
from datetime import datetime
import time

# Function to convert date to Unix timestamp
def date_to_unix_timestamp(date_str):
    date_obj = datetime.strptime(date_str, "%Y-%m-%d")
    return int(time.mktime(date_obj.timetuple()))

# Function to fetch historical exchange data using yfinance
def fetch_historical_data(quote, from_date_str, to_date_str):
    # Convert from and to dates to Unix timestamps
    from_date = date_to_unix_timestamp(from_date_str)
    to_date = date_to_unix_timestamp(to_date_str)
    
    # Download historical data using yfinance
    data = yf.download(quote, start=from_date_str, end=to_date_str, interval="1d")
    
    # Check if the data is empty
    if data.empty:
        raise Exception("No data found for the specified range.")
    
    return data

# Function to store the fetched data in SQLite database
def store_data_in_sqlite(dataframe, db_name=":memory:"):
    # Connect to SQLite (in-memory or file)
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()

    # Create a table
    table_name = "historical_exchange_data"
    dataframe.to_sql(table_name, conn, if_exists="replace", index=True)
    
    # Query the database to verify
    cursor.execute(f"SELECT * FROM {table_name} LIMIT 5;")
    rows = cursor.fetchall()
    print("Sample data from SQLite database:")
    for row in rows:
        print(row)
    
    # Close the connection
    conn.close()

if __name__ == "__main__":
    # Get user input
    try:
        quote = input("Enter the currency pair (e.g., EURUSD=X): ").strip()
        from_date_str = input("Enter the start date (YYYY-MM-DD): ").strip()
        to_date_str = input("Enter the end date (YYYY-MM-DD): ").strip()

        # Scrape historical data
        historical_data = fetch_historical_data(quote, from_date_str, to_date_str)
        print("Historical data fetched successfully.")
        
        # Store data in SQLite
        store_data_in_sqlite(historical_data, db_name="data.db")  # Change ":memory:" to "data.db" to save to a file
    except Exception as e:
        print(f"Error: {e}")
