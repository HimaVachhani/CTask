from flask import Flask, request, jsonify
from datetime import datetime, timedelta
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

# Function to convert period (e.g., 1M, 3M) to timedelta
def convert_period_to_timedelta(period):
    if period.endswith('M'):  # For months
        months = int(period[:-1])
        today = datetime.now()
        start_date = today - timedelta(days=30 * months)  # Approximate 30 days per month
        return today - start_date
    elif period.endswith('D'):  # For days
        days = int(period[:-1])
        return timedelta(days=days)
    else:
        raise ValueError("Unsupported period format. Use '1M', '3M', etc.")

# Function to fetch historical forex data from Yahoo Finance
def fetch_yahoo_forex_data(from_currency, to_currency, from_date, to_date):
    # Convert dates to Unix timestamps (seconds since epoch)
    period1 = int(from_date.timestamp())
    period2 = int(to_date.timestamp())

    # URL for Yahoo Finance historical data
    url = f"https://finance.yahoo.com/quote/{from_currency}{to_currency}=X/history/?period1={period1}&period2={period2}"

    # Send request to fetch the data
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception("Failed to retrieve data from Yahoo Finance")

    # Parse the page content
    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table', {'data-test': 'historical-prices'})
    rows = table.find_all('tr')

    forex_data = []
    for row in rows[1:]:  # Skip the header row
        columns = row.find_all('td')
        if len(columns) > 1:
            date_str = columns[0].get_text()
            try:
                date = datetime.strptime(date_str, '%b %d, %Y')
            except ValueError:
                continue  # Skip rows with invalid dates
            close_price = columns[4].get_text().replace(',', '')
            forex_data.append({"date": date.strftime("%Y-%m-%d"), "rate": float(close_price)})
    
    return forex_data

# Endpoint to get forex data
@app.route('/api/forex-data', methods=['POST'])
def get_forex_data():
    try:
        # Extract request data
        data = request.get_json()
        print(f"Request data: {data}")  # Debugging line
        from_currency = data.get("from")
        to_currency = data.get("to")
        period = data.get("period")

        # Validate inputs
        if not from_currency or not to_currency or not period:
            return jsonify({"error": "Missing parameters. Please provide 'from', 'to', and 'period'."}), 400

        # Convert period to timedelta
        try:
            period_timedelta = convert_period_to_timedelta(period)
        except ValueError:
            return jsonify({"error": "Unsupported period format. Use '1M', '3M', etc."}), 400
        
        # Calculate the date range based on the period
        end_date = datetime.now()
        start_date = end_date - period_timedelta

        # Fetch the forex data from Yahoo Finance
        try:
            forex_data = fetch_yahoo_forex_data(from_currency, to_currency, start_date, end_date)
        except Exception as e:
            return jsonify({"error": f"Failed to retrieve data: {str(e)}"}), 500
        
        # If no data is found in the requested period
        if not forex_data:
            return jsonify({"error": "No data found for the requested period."}), 404
        
        print(f"Filtered data: {forex_data}")  # Debugging line
        # Return the filtered forex data
        return jsonify(forex_data)

    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)
