import requests
from bs4 import BeautifulSoup

def fetch_data(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    try:
        response = requests.get(url, headers=headers)
        print(f"Response Status Code: {response.status_code}")
        
        if response.status_code == 200:
            print("Data fetched successfully")
            return response.text
        else:
            print(f"Failed to fetch data. Status code: {response.status_code}")
            return None
    except Exception as e:
        print(f"Error: {e}")
        return None

def extract_historical_data(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Find the table with the class 'markets-table'
    table = soup.find('table', {'class': 'markets-table'})
    
    if not table:
        print("No data table found.")
        return []

    rows = table.find_all('tr')  # Find all rows
    data = []

    # Loop through rows and extract data
    for row in rows[1:]:  # Skip header row
        columns = row.find_all('td')
        if len(columns) > 1:  # Ensure row has data
            symbol = columns[0].text.strip()
            name = columns[1].text.strip()
            last_price = columns[2].text.strip()
            sector = columns[3].text.strip()
            type_ = columns[4].text.strip()
            exchange = columns[5].text.strip()
            
            data.append({
                'symbol': symbol,
                'name': name,
                'last_price': last_price,
                'sector': sector,
                'type': type_,
                'exchange': exchange
            })

    return data

# Example URL for AED-INR (update the URL if necessary)
currency_pair = "AEDINR"
period1 = "1726723052"  # Example timestamp
period2 = "1733980652"  # Example timestamp
url = f"https://finance.yahoo.com/quote/{currency_pair}/history/?period1={period1}&period2={period2}"

# Fetch the HTML content
html_content = fetch_data(url)

if html_content:
    data = extract_historical_data(html_content)
    if data:
        print("Extracted Data:", data)
    else:
        print("No data extracted.")
